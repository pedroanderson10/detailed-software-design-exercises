
package br.com.ufc.pds.serpentesEscadas.casa;

public interface iCasaController extends iSetGetCasaGoTo,iSetGetCasa,iSetGetCasaNormal,
        iSetGetCasaRandom{
}

