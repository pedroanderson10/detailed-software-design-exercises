
package br.com.ufc.pds.serpentesEscadas.casa;

public interface iCasaRandom {
    public int getDestinoSorte();
    public int getDestinoReves();
}

