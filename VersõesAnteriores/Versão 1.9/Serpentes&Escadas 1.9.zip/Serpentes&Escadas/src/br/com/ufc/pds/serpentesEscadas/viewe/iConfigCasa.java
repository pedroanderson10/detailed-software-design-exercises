
package br.com.ufc.pds.serpentesEscadas.viewe;

public interface iConfigCasa {
	public void definirCasas();
	public void setCasaDestino(int casaDestino);
    public int getCasaDestino();
    public int getCasaAtual();
    public boolean casaRand();
}
