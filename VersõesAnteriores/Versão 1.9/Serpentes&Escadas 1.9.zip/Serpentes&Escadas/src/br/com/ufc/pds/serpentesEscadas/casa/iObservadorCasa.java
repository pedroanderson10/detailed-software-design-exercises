
package br.com.ufc.pds.serpentesEscadas.casa;

public interface iObservadorCasa {
    public void caiuNaRandom();
}
