package br.com.ufc.pds.serpentesEscadas.casa;
public interface iCasa {
    public int getDestino();
    public int getNumCasa();
	public int getY() ;
	public void setY(int y) ;
	public int getX() ;
	public void setX(int x) ;

}
