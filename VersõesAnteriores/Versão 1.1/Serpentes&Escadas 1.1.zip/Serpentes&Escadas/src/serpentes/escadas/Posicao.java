/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serpentes.escadas;

/**
 *
 * @author paulo
 */
public class Posicao {
    private int coordenada_X = 0;
    private int coordenada_Y = 0;
    
    public Posicao(){
    }
    
    public Posicao(int x, int y){
        this.coordenada_X = x;
        this.coordenada_Y = y;
    }
}
