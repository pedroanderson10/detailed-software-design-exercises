package serpentes.escadas;
public interface iCasa {
    public  int getDestino();
}
