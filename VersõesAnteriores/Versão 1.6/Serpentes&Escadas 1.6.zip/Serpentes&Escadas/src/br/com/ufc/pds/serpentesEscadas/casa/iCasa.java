package br.com.ufc.pds.serpentesEscadas.casa;
public interface iCasa {
    public int getDestino();
    public int getNumCasa();
}
