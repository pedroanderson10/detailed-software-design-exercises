
package br.com.ufc.pds.serpentesEscadas.viewe;

public interface iConfigJogo extends iConfigCasa,iConfigJogador {
}
