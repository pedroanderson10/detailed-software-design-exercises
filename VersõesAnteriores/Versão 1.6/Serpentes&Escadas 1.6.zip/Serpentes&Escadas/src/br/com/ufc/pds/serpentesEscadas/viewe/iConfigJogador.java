
package br.com.ufc.pds.serpentesEscadas.viewe;

import br.com.ufc.pds.serpentesEscadas.tabuleiro.iTabuleiroController;

public interface iConfigJogador {
    public iTabuleiroController definirJogadores(iTabuleiroController ctrlTabuleiro);
}
