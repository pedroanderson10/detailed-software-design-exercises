package serpentes.escadas;

public class SerpentesEscadas {
    public static void main(String[] args) {
        // TODO code application logic here
    }   
}
