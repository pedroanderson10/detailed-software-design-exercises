
package br.com.ufc.pds.serpentesEscadas.viewe;

import br.com.ufc.pds.serpentesEscadas.tabuleiro.iTabuleiroController;

public interface iConfigCasa {
    public iTabuleiroController definirCasas(iTabuleiroController ctrlTabuleiro);
}
