
package br.com.ufc.pds.serpentesEscadas.viewe;

public class Posicao {
    private int coordenada_X = 0;
    private int coordenada_Y = 0;
    
    public Posicao(){
    }
    
    public Posicao(int x, int y){
        this.coordenada_X = x;
        this.coordenada_Y = y;
    }
}
