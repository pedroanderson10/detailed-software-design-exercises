
package serpentes.escadas;

public interface iCasaRandom {
    public int getDestinoSorte();
    public int getDestinoReves();
}

