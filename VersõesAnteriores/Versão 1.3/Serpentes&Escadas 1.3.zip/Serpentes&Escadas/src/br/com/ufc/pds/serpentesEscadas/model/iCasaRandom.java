
package br.com.ufc.pds.serpentesEscadas.model;

public interface iCasaRandom {
    public int getDestinoSorte();
    public int getDestinoReves();
}

