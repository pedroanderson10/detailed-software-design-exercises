package br.com.ufc.pds.serpentesEscadas.model;
public interface iCasa {
    public int getDestino();
}
